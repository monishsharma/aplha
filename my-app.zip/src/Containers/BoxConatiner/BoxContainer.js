import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import SelectedValue from '../../Component/SelectedValueContainer/SelectedValue';
import OptionContainer from '../../Component/OptionContainer/OptionContainer'
const BoxContainer = () => {
  return (
    <div>
      <Container>
        <div className="grid2x2">
            <OptionContainer />
            <SelectedValue />
        </div>
      </Container>
    </div>
  );
};

export default BoxContainer;
