import React from 'react';
import NavBar from './Component/NavBar/NavBar';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import BoxContainer from './Containers/BoxConatiner/BoxContainer'

function App() {
  return (
    <div className="App">
      <NavBar />
      <BoxContainer />
    </div>
  );
}

export default App;
