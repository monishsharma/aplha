import React, { Component } from "react";
import { connect } from "react-redux";
import * as actions from "../../Store/Actions/index";
class OptionContainer extends Component {
    componentWillUpdate(){
   setTimeout(() => {
        var checkboxes = document.querySelectorAll('input[type=checkbox]:checked')
        for (var i = 0; i < checkboxes.length; i++) {
        if( checkboxes[i].value == this.props.checked ){
            checkboxes[i].checked = false
        }
        }
   }, 100);

    }
  addItem = (e, item, heading,index) => {
    if (e.target.checked) {
      this.props.addItem(item,heading,index);
    }
    else{
        this.props.removeItem(item)
    }
  };
  render() {
    return (
      <div>
        <div className="box box1">
          {this.props.options.map((option, index) => {
            return (
              <div className="options" key={index+1}>
                <div className="heading">
                  <h4>{option.heading}</h4>
                  <div className="optionName">
                    {option.options.map((selectableOption, index) => {
                      return (
                        <ul key={index}>
                          <li>
                            <label>
                              <input
                                onChange={(e) =>
                                  this.addItem(
                                    e,
                                    selectableOption,
                                    option.heading,
                                    option.index
                                  )
                                }
                                id = {'check?_'+index}
                                className="input"
                                type="checkbox"
                                value = {selectableOption}
                              />
                              {selectableOption}
                            </label>
                          </li>
                        </ul>
                      );
                    })}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    options: state.options.options,
    checked: state.options.checked,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    addItem: (selectedItem,heading,index) => dispatch(actions.addItem(selectedItem,heading,index)),
    removeItem: (selectedItem) => dispatch(actions.removeItem(selectedItem)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(OptionContainer);
