import React from "react";
import './NavBar.css';
import { Navbar, Nav, Container } from "react-bootstrap";
const NavBar = () => {
  return (
    <div>
      <Navbar className = "mainNavbar" collapseOnSelect expand="lg" >
      <Container>
      <Navbar.Brand href="#home">LOGO</Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="mr-auto"></Nav>
          <Nav className = "navlinks">
            <Nav.Link href="#features">Home</Nav.Link>
            <Nav.Link href="#pricing">My Portfolio</Nav.Link>
            <Nav.Link href="#deets">Clients </Nav.Link>
            <Nav.Link eventKey={2} href="#memes">
              Get in Touch
            </Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
      </Navbar>
    </div>
  );
};

export default NavBar;
