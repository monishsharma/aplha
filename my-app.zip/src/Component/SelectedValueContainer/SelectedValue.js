import React, { Component } from "react";
import { connect } from "react-redux";
import * as actions from "../../Store/Actions/index";

class SelectedValue extends Component {
  render() {
    return (
      <div>
        <div className="box box2">
          {this.props.selectedItems.length == 0 ? (
            <p className="text-center empty">No item selected</p>
          ) : (
            this.props.selectedItems.map((item,index) => {
              return (
                <div key = {index}>
                  <div className="heading">
                    {
                      <h4>{item.heading}</h4> 
                    }
                    <div className="items">
                      {item.item}
                      <span
                        className="close float-right"
                        onClick={() => this.props.removeItem(item.item)}
                      >
                        &times;
                      </span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    selectedItems: state.options.selected,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    removeItem: (selectedItem) => dispatch(actions.removeItem(selectedItem)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(SelectedValue);
