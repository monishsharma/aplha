import { createStore, compose } from "redux";
import  rootReducer  from './RootReducer';

// const composeEnhancers = ;
export const store = createStore(rootReducer,window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__());

export default store;   