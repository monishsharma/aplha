import * as actionTypes from './ActionsTypes';

export const addItem = (selectedItems,category,index) => {
    return{
        type : actionTypes.ADD_ITEMS,
        selectedItems: selectedItems,
        category : category,
        index : index
    }
}

export const removeItem = (selectedItems) => {
    return{
        type : actionTypes.DELETE_ITEMS,
        selectedItems: selectedItems,
    }
}