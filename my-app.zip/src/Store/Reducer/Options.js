import * as actionTypes from "../Actions/ActionsTypes";
const initialState = {
  options: [
    {
      heading: "Portugal",
      options: [
        "Abrantes",
        "Agualva-Cacém",
        "Águeda",
        "Albufeira",
        "Alcácer do Sal",
      ],
      index:0,
    },
    {
      heading: "Nicaragua",
      options: ["Managua", "León", "Matagalpa", "Chinandega"],
      index:1,

    },
    {
      heading: "Marshall Islands",
      options: [
        "Arno Atoll",
        "Kalalin Pass",
        " Ebeye Island",
        "Maloelap Atoll",
      ],
      index :2
    },
  ],
  selected: [],
  checked:'',
  loading:false
};

const Options = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.ADD_ITEMS:
      {
        let addedItem = {
          item: action.selectedItems,
          heading: action.category,
          index:action.index
        };

        return {
          ...state,
          selected: [...state.selected, addedItem],

        };
      }
      break;
    case actionTypes.DELETE_ITEMS: {
      const deletedTodo = state.selected.filter(
        (item) => action.selectedItems !== item.item
      );
      return {
        ...state,
        selected: deletedTodo,
        checked:action.selectedItems
      };
    }
    default:
      return state;
  }
};

export default Options;
