import optionReducer from "./Reducer/Options";
import { combineReducers } from "redux";

const rootReducer = combineReducers({
  options:optionReducer
});


export default rootReducer
